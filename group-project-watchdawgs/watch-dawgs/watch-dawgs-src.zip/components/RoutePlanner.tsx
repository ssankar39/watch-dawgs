'use client';

import Image from 'next/image';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Car } from 'lucide-react';
import { useState } from 'react';

export function RoutePlanner({ user }: { user: any }) {
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');

  const handlePlan = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement route planning
    console.log('Planning route from', start, 'to', end);
    // Clear form inputs after submission
    setStart('');
    setEnd('');
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Car className="h-5 w-5" />
            Route Planner
          </CardTitle>
          <CardDescription>
            Plan your route and get real-time navigation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlePlan} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Starting Location
              </label>
              <input
                type="text"
                value={start}
                onChange={(e) => setStart(e.target.value)}
                placeholder="Enter start location"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#BA0C2F] focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Destination
              </label>
              <input
                type="text"
                value={end}
                onChange={(e) => setEnd(e.target.value)}
                placeholder="Enter destination"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#BA0C2F] focus:border-transparent"
                required
              />
            </div>

            <Button type="submit" className="w-full bg-[#BA0C2F] hover:bg-red-800">
              Plan Route
            </Button>
          </form>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-semibold text-gray-900 mb-2">Route Options</h4>
            <p className="text-sm text-gray-600">
              After planning, fastest and alternative routes will appear here
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
