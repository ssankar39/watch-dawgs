'use client';

import Image from 'next/image';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from './ui/card';
import { Bus } from 'lucide-react';

export function BusTracker({ user }: { user: any }) {
  const mockBuses = [
    {
      id: '1',
      route: '1',
      destination: 'North Campus',
      arrivalTime: '5 mins',
      nextStop: 'Biology Building',
    },
    {
      id: '2',
      route: '2',
      destination: 'South Campus',
      arrivalTime: '12 mins',
      nextStop: 'Student Center',
    },
    {
      id: '3',
      route: '3',
      destination: 'Downtown',
      arrivalTime: '8 mins',
      nextStop: 'Library',
    },
  ];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bus className="h-5 w-5" />
            Bus Tracker
          </CardTitle>
          <CardDescription>
            Real-time bus locations and arrival times
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockBuses.map((bus) => (
              <div
                key={bus.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">Route {bus.route}</h4>
                    <p className="text-sm text-gray-600">{bus.destination}</p>
                    <p className="text-xs text-gray-500 mt-1">Next stop: {bus.nextStop}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-[#BA0C2F]">{bus.arrivalTime}</p>
                    <p className="text-xs text-gray-500">Arrival</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-900">
              📍 Tip: Enable location services for more accurate arrival times
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
