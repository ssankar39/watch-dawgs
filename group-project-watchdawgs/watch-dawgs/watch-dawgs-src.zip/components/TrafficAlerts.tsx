'use client';

import Image from 'next/image';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from './ui/card';
import { AlertTriangle } from 'lucide-react';

export function TrafficAlerts() {
  const mockAlerts = [
    {
      id: '1',
      type: 'Accident',
      location: 'North Campus Drive',
      severity: 'high',
      message: 'Accident near parking lot - expect delays',
      time: '5 mins ago',
    },
    {
      id: '2',
      type: 'Road Work',
      location: 'South Campus',
      severity: 'medium',
      message: 'Road construction on main entrance',
      time: '1 hour ago',
    },
    {
      id: '3',
      type: 'Heavy Traffic',
      location: 'Sanford Stadium',
      severity: 'medium',
      message: 'Increased traffic due to event',
      time: '2 hours ago',
    },
  ];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Traffic Alerts
          </CardTitle>
          <CardDescription>
            Current traffic alerts and advisories
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`border-l-4 p-4 rounded-lg ${
                  alert.severity === 'high'
                    ? 'border-red-500 bg-red-50'
                    : 'border-yellow-500 bg-yellow-50'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{alert.type}</h4>
                    <p className="text-sm text-gray-600">{alert.location}</p>
                    <p className="text-sm text-gray-700 mt-1">{alert.message}</p>
                  </div>
                  <span className="text-xs text-gray-500 whitespace-nowrap ml-2">
                    {alert.time}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
