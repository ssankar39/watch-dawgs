'use client';

import Image from 'next/image';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from './ui/card';
import { MapPin, AlertCircle } from 'lucide-react';

export function TrafficMapView({ user }: { user: any }) {
  const mockIncidents = [
    {
      id: '1',
      location: 'North Campus Drive',
      type: 'Heavy Traffic',
      severity: 'high',
      description: 'Congestion near parking lot',
    },
    {
      id: '2',
      location: 'Sanford Stadium',
      type: 'Accident',
      severity: 'high',
      description: 'Minor fender bender',
    },
    {
      id: '3',
      location: 'South Campus',
      type: 'Construction',
      severity: 'medium',
      description: 'Road maintenance in progress',
    },
  ];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Live Traffic Map
          </CardTitle>
          <CardDescription>
            Real-time incidents and traffic conditions on UGA campus
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-gray-100 rounded-lg h-96 flex items-center justify-center mb-4">
            <p className="text-gray-500">Interactive map would load here</p>
          </div>

          <h3 className="text-lg font-semibold mb-4">Recent Incidents</h3>
          <div className="space-y-3">
            {mockIncidents.map((incident) => (
              <div
                key={incident.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-900">{incident.location}</h4>
                    <p className="text-sm text-gray-600">{incident.type}</p>
                    <p className="text-sm text-gray-700 mt-1">{incident.description}</p>
                  </div>
                  <span
                    className={`px-2 py-1 text-xs rounded font-medium ${
                      incident.severity === 'high'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}
                  >
                    {incident.severity}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
