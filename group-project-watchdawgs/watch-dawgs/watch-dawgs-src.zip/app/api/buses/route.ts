import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/lib/mongodb';
import BusLocation from '@/lib/models/BusLocation';

// GET all buses or specific bus
export async function GET(request: NextRequest) {
  try {
    await dbConnect();

    const { searchParams } = new URL(request.url);
    const busId = searchParams.get('busId');

    let query: any = {};
    if (busId) query.busId = busId;

    const buses = await BusLocation.find(query).sort({ updatedAt: -1 });

    return NextResponse.json({ buses }, { status: 200 });
  } catch (error: any) {
    return NextResponse.json(
      { error: 'Failed to fetch buses' },
      { status: 500 }
    );
  }
}

// POST/UPDATE bus location
export async function POST(request: NextRequest) {
  try {
    await dbConnect();

    const { busId, latitude, longitude, route, destination } =
      await request.json();

    if (!busId || latitude === undefined || longitude === undefined) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const bus = await BusLocation.findOneAndUpdate(
      { busId },
      {
        busId,
        latitude,
        longitude,
        route,
        destination,
      },
      { upsert: true, new: true }
    );

    return NextResponse.json(
      { message: 'Bus location updated', bus },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { error: 'Failed to update bus location' },
      { status: 500 }
    );
  }
}
